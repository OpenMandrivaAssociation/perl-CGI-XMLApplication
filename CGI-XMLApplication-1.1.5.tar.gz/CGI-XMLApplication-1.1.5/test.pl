print "ok\n";

